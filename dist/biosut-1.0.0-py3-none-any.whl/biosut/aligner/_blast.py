"""
The :mod:`biosut.aligner._blast` run blast tool box.
"""

# Author Jie Li (mm.jlli6t@gmail.com)
# License: GNU v3.0

import os

class blast(object):
	"""Wrapper for running blast"""

	def __init__(self, fasta, db, )
